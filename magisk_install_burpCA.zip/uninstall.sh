rm -f /system/etc/security/cacerts/9a5ba575.0
